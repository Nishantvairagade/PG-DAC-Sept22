class P11
{
	public static void main(String[] args)
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("*****");
			for(int j=0;j<=i;j++)
				System.out.print(" ");
		}
	}
}
/*
OUTPUT:

C:\Users\dhuma\Desktop\C-DAC\Pattern Que\Assignment 2\Type 2>java P11
*****
 *****
  *****
   *****
    *****
	
*/